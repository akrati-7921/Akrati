package com.cg.lab8.ui;

import java.util.Random;

class Number implements Runnable
{ 
	private static int num;
	public void run()
	{
		try
		{
			Random ran=new Random();
			num=ran.nextInt(20);
			System.out.println("Number is:"+num);
		}
		catch(Exception exp)
		{
			System.out.println(exp);
		}
	}
	public static int display()
	{
		return num;
	}
}

class FactorialFind implements Runnable
{ 
	public void run()
	{
		try
		{
			int numb=Number.display();
			long fact=1;
			for(int i=1;i<=numb;i++)
			{
			fact=fact*i;	
			}
			System.out.println("Factorial is:"+fact);
		}
		catch(Exception exp)
		{
			System.out.println(exp);
		}
	}
}

public class Factorial {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		
		Runnable ob1=new Number();
		Thread number=new Thread(ob1);
		Runnable ob2=new FactorialFind();
		Thread factorial=new Thread(ob2);
		number.start();
		number.join();
		factorial.start();
		
		

	}

}
