package com.cg.lab8.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DisplayTimer implements Runnable{
	
	public void run()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Timer is: "+dtf.format(now)); 
		while(true)
		{
			try
			{
				Thread.sleep(10000);
			}
			catch(InterruptedException e)
			{
				System.out.println("Thread Interruped...");
			}
			LocalDateTime changed = LocalDateTime.now();
			System.out.println("Updated time is: "+dtf.format(changed)); 
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DisplayTimer timer=new DisplayTimer();
		Thread displayTimer=new Thread(timer);
		displayTimer.start();
	}

}
