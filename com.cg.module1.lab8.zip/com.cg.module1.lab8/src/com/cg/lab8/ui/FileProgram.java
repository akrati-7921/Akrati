package com.cg.lab8.ui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CopyDataThread s=null;
	     try {
	    	 
			 s=new CopyDataThread(new FileReader("C:\\practice\\com.cg.module1.lab8\\src\\com\\cg\\lab8\\ui\\input.txt"),new FileWriter("C:\\practice\\com.cg.module1.lab8\\src\\com\\cg\\lab8\\ui\\output.txt"));
		}
	     catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	     catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     s.start();
	}

}
