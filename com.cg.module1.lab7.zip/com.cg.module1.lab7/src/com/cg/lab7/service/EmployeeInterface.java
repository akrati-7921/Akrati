package com.cg.lab7.service;

import java.util.Map;

import com.cg.lab7.bean.Employee;

public interface EmployeeInterface {

	public void addEmployee(Map<Integer, Employee> emplist);
	public void dislpayDetails(Map<Integer, Employee> emplist);
	public boolean deleteEmployee(Map<Integer, Employee> emplist);

}
