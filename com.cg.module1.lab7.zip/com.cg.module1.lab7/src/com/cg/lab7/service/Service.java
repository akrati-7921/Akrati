package com.cg.lab7.service;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.lab7.bean.Employee;

public class Service implements EmployeeInterface{

	Scanner scan=new Scanner(System.in);
	Employee e=new Employee();
	@Override
	public void addEmployee(Map<Integer, Employee> emplist) {
	
		// TODO Auto-generated method stub
		
		System.out.println("Enter employee name");
		String ename=scan.next();
		System.out.println("Enter employee designation");
		String edesig=scan.next();
		System.out.println("Enter insurance scheme");
		String einsurance=scan.next();
		scan.nextLine();
		System.out.println("Enter employee salary");
		double esal=scan.nextDouble();
		System.out.println("Enter the employee id u want to add");
		int eid=scan.nextInt();
	    emplist.put(eid,new Employee(ename,edesig,einsurance,esal));
	}

	@Override
	public void dislpayDetails(Map<Integer, Employee> emplist) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the insurance scheme");
		String ins=scan.next();

		Iterator<Integer> iterate=emplist.keySet().iterator();
		while(iterate.hasNext())
		{
			Integer key=iterate.next();
			e =emplist.get(key);
			if(e.getInsuranceScheme().equals(ins))
			{
				System.out.println(e);
			}	
		}
	}

	@Override
	public boolean deleteEmployee(Map<Integer, Employee> emplist) {
		// TODO Auto-generated method stub
		System.out.println("Enter the id u want to delete");
		scan.nextLine();
		int id=scan.nextInt();
		boolean flag=false;
		Iterator<Integer> iterate=emplist.keySet().iterator();
		while(iterate.hasNext())
		{
			Integer key=iterate.next();
			if(key==id)
			{
				emplist.remove(key);
				System.out.println("Deleted successfully");
				flag= true;
			}	
			else
			{
				flag= false;
			}
		}
		return flag;
	}

	public void display(Set<Integer> sort) {
		// TODO Auto-generated method stub
		Iterator<Integer> iterator = sort.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + " \n");
		}
	}
	

}
