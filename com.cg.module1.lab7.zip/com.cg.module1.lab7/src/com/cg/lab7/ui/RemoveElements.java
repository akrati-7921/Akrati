package com.cg.lab7.ui;

import java.util.ArrayList;
import java.util.List;

public class RemoveElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list1=new ArrayList<>();
		List<String> list2=new ArrayList<>();
		
		list1.add("Dog");
		list1.add("Cat");
		list1.add("Lion");
		list1.add("Tiger");
		list1.add("Elephant");
		
		list2.add("Mouse");
		list2.add("Cat");
		list2.add("Dog");
		list2.add("Fish");
		List<String> result=removeListElement(list1,list2);
		System.out.println(result);

	}

	private static List<String> removeListElement(List<String> list1, List<String> list2) {
		// TODO Auto-generated method stub
		
		list1.removeAll(list2);
		return list1;
	}

}
