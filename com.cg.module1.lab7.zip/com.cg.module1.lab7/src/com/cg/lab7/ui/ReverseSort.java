package com.cg.lab7.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class ReverseSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter the number of elements");
		Scanner scan=new Scanner(System.in);
		int range=scan.nextInt();
		int[] arr=new int[range];
		System.out.println("Enter the elements");
		for(int i=0;i<range;i++)
		{
			arr[i]=scan.nextInt();
		}
		scan.close();
		for(String s:getSorted(arr))
		{
			System.out.println(s);
		}
	}

	private static String[] getSorted(int[] arr) {
		// TODO Auto-generated method stub
		
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<arr.length;i++)
		{
			sb.append(arr[i]);
			sb.append("\n");
		}
		sb.reverse();
		String extra=sb.substring(1,sb.length());
		String[] str=extra.split("\n");
		ArrayList<String> sortList=new ArrayList<String>(Arrays.asList(str));
		Collections.sort(sortList);
		String[] result= new String[sortList.size()];
		sortList.toArray(result);
		return result;
	}

	
}
