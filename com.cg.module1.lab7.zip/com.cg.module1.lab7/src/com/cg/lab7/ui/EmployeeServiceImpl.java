package com.cg.lab7.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.cg.lab7.bean.Employee;
import com.cg.lab7.service.Service;

public class EmployeeServiceImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan=new Scanner(System.in);
		Map<Integer,Employee> emplist=new HashMap<Integer, Employee>();
		Service s=new Service();
		while(true)
		{
			System.out.println("1.Add employee Details\n2.Display on the insurance basis\n3.Delete an "
					+ "employee\n4.Sort\n5.Exit\nEnter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				s.addEmployee(emplist);
				break;
			case 2:
				s.dislpayDetails(emplist);
				break;
			case 3:
				if(!s.deleteEmployee(emplist))
				{
					System.out.println("id does not exist");
				}
				break;
			case 4:
				Set<Integer> sort=new TreeSet(emplist.values());
				s.display(sort);
				break;
			case 5:
				System.exit(0);
				break;
			default: 
				System.out.println("wrong option");
				break;
				
			}
		}
		
	}
}
