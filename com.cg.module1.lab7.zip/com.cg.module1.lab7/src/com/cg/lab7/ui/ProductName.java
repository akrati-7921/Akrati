package com.cg.lab7.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> product=new ArrayList<>();
		
		product.add("ParleG");
		product.add("Sunfeast");
		product.add("Bourbon");
		product.add("Hide & Seek");
		
		Collections.sort(product);
		
		for(String iter:product)
		{
			System.out.println(iter);
		}
	}

}
