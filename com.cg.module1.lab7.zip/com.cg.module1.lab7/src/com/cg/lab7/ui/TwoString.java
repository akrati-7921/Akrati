package com.cg.lab7.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class TwoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the first string");
		String s1=scan.next();
		System.out.println("Enter the second string");
		String s2=scan.next();
		scan.close();
		System.out.println(TwoString.stringGame(s1,s2));
	}

	private static List<String> stringGame(String s1, String s2) {
		// TODO Auto-generated method stub
		List<String> myList= new ArrayList<>();
		StringBuilder result1=new StringBuilder();
		StringBuilder result2=new StringBuilder();
		StringBuilder result4=new StringBuilder();
		
		// case 1
		for(int i=0;i<s1.length();i++)
		{
			if(i%2==1)
			{
				result1.append(s2);
			}
			else
			{
				result1.append(s1.charAt(i));
			}
		}
		myList.add(result1.toString());
		
		
		// case 2
		int lastIndex=0;
		int count=0;
		while(lastIndex!=-1)
		{
			lastIndex=s1.indexOf(s2,lastIndex);
			if(lastIndex!=-1)
			{
				count++;
				lastIndex+=s2.length();
			}
		}
		int start=s1.lastIndexOf(s2);
		if(count>1)
		{
			StringBuilder reverseString=new StringBuilder();
			reverseString.append(s2);
			reverseString=reverseString.reverse();
			result2.append(s1.substring(0,start));
			result2.append(reverseString);
			result2.append(s1.substring(start+s2.length()));
			myList.add(result2.toString());
		}
		else
		{
			myList.add(s1+s2);
		}
		
		
		// case 3
		if(count>1)
		{
			s1=s1.replaceFirst(Pattern.quote(s2),"");
			myList.add(s1);
		}
		else
		{
			myList.add(s1);
		}
			
		
		// case 4
		if(s2.length()%2==0)
		{
			result4.append(s2.substring(0,s2.length()/2));
			result4.append(s1);
			result4.append(s2.substring(s2.length()/2,s2.length()));
		}
		else if(s2.length()%2==1)
		{
			result4.append(s2.substring(0,s2.length()/2+1));
			result4.append(s1);
			result4.append(s2.substring(s2.length()/2+1,s2.length()));
		}
		myList.add(result4.toString());
	
		
		// case 5
		for(int i=0;i<s1.length();i++)
		{
			for(int j=0;j<s2.length();j++)
			{
				if(s1.charAt(i)==s2.charAt(j))
				{
					s1=s1.replace(s1.charAt(i),'*');
				}
			}
		}
		myList.add(s1);
		
		return myList;
	}

}
