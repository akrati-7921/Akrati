package com.cg.lab7.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Squares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int n=scan.nextInt();
		int[] elements=new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++)
		{
			elements[i]=scan.nextInt();
		}
		Map<Integer,Integer> result= getSquare(elements);
		Iterator<Integer> iterate=result.keySet().iterator();
		while(iterate.hasNext())
		{
			Integer key=iterate.next();
			System.out.println(key+ ":" +result.get(key));
		}
		scan.close();
	}

	private static Map<Integer, Integer> getSquare(int[] elements) {
		// TODO Auto-generated method stub
		Map<Integer,Integer> findSquares=new HashMap<>();
		for(Integer range:elements)
		{
			findSquares.put(range, range*range);
		}
		return findSquares;
	}

}
