package com.cg.lab7.bean;

import java.util.Comparator;

public class Employee implements Comparable<Employee>{
	
	private int id;
	private String name;
	private String designation;
	private String insuranceScheme;
	private double salary;
	
	public Employee() {
		super();
	}
	
	public Employee(String name, String designation, String insuranceScheme, double salary) {
		super();
		this.name = name;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
		this.salary = salary;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDesignation() {
		return designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public double getSalary() {
		return salary;
	}
	
	@Override
	public String toString() {
		return "Employee [ "+" name=" + name + ", designation=" + designation + ", insuranceScheme="
				+ insuranceScheme + ", salary=" + salary + "]";
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return (int)this.getSalary()-(int)o.getSalary();
	}

}
