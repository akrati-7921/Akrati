package com.cg.module2.jdbc.ui;

import java.util.Scanner;

import com.cg.module2.jdbc.service.EmployeeService;

public class EmployeeUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeService service=new EmployeeService();
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Add employee Details\n2.Display on the insurance basis\n3.Delete an "
					+ "employee\n4.Sort\n5.Exit\nEnter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter Employee id");
				int id=scan.nextInt();
				System.out.println("Enter Employee Name");
				scan.nextLine();
				String name=scan.nextLine();
				System.out.println("Enter Employee Designaton");
				String des=scan.nextLine();
				System.out.println("Enter salary of employee");
				double sal=scan.nextDouble();
				service.addEmployee(id, name, des, sal);
				break;
			case 2:
				System.out.println("Enter the Insurance Scheme whom details you want");
				scan.nextLine();
				String ins=scan.nextLine();
				service.displayEmployee(ins);
				break;
			case 3:
				System.out.println("Enter the id you want to delete");
				int delId=scan.nextInt();
				service.deleteEmployee(delId);
				break;
			case 4:
				service.sortEmployee();
				break;
			case 5:
				System.exit(0);
				break;
			default: 
				System.out.println("wrong option");
				break;
				
			}
		}
	}

}
