package com.cg.module2.jdbc.service;

import com.cg.module2.jdbc.bean.Employee;
import com.cg.module2.jdbc.repository.EmployeeRepository;

public class EmployeeService implements IEmployeeService{

	EmployeeRepository empRepo=null;
	
	public EmployeeService()
	{
		empRepo=new EmployeeRepository();
	}
	@Override
	public void addEmployee(int id, String name, String des, double sal) {
		// TODO Auto-generated method stub
		empRepo.addEmployee(id, name, des, sal);
	}

	@Override
	public void displayEmployee(String ins_sch) {
		// TODO Auto-generated method stub
		empRepo.displayEmployee(ins_sch);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		empRepo.deleteEmployee(id);
	}

	@Override
	public void sortEmployee() {
		// TODO Auto-generated method stub
		empRepo.sortEmployee();
	}
	
}
