package com.cg.module2.jdbc.repository;

public interface IEmployeeRepository {

	public void addEmployee(int id,String name,String des,double sal);
	public void displayEmployee(String ins_sch);
	public void deleteEmployee(int id);
	public void sortEmployee();
	
	public void insertInsurance(String des,double sal);
}
