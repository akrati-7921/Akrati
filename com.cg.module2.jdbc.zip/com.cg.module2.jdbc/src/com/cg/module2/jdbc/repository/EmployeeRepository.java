package com.cg.module2.jdbc.repository;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import com.cg.module2.jdbc.util.DBUtil;

public class EmployeeRepository implements IEmployeeRepository{

	Connection con=null;
	Statement st=null;
	
	@Override
	public void addEmployee(int id, String name, String des, double sal) {
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getCon();
			String insertQry="INSERT INTO emp_jdbc(emp_id,emp_name,emp_des,emp_sal) VALUES (?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(insertQry);
			pst.setInt(1,id);
			pst.setString(2,name);
			pst.setString(3,des);
			pst.setDouble(4,sal);
			pst.executeUpdate();
			insertInsurance(des,sal);
			System.out.println("Data is inserted... ");
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void displayEmployee(String ins_sch) {
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getCon();
			String disInsQry="Select * from emp_jdbc where emp_ins='" +ins_sch+"'";
			PreparedStatement pst = con.prepareStatement(disInsQry);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String des=rs.getString(3);
				double salary=rs.getDouble(4);
				String ins=rs.getString(5);
				System.out.println("Emp Id:\t"+id+"\nEmp Name:\t"+name+"\nEmp designation:\t"
						+des+"\nEmp salary:\t"+salary+"\nEmp insurance:\t"+ins);
			}
		}
		catch (SQLException | IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		
		try {
			con=DBUtil.getCon();
			String deleteQry="DELETE from emp_jdbc WHERE emp_id=?";
			PreparedStatement pst = con.prepareStatement(deleteQry);
			pst.setInt(1,id);
			pst.executeUpdate();
			System.out.println("Data is deleted... ");
		}
		catch (SQLException | IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void sortEmployee() {
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getCon();
			String sortQry="Select * from emp_jdbc order by emp_sal";
			st = con.createStatement();
			ResultSet rs=st.executeQuery(sortQry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String des=rs.getString(3);
				double salary=rs.getDouble(4);
				String ins=rs.getString(5);
				System.out.println("Emp Id:\t"+id+"\nEmp Name:\t"+name+"\nEmp designation:\t"
						+des+"\nEmp salary:\t"+salary+"\nEmp insurance:\t"+ins);
			}
		}
		catch (SQLException | IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertInsurance(String des,double sal) {
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getCon();
			CallableStatement cst=con.prepareCall("call emp_jdbc_proc(?,?,?)");
			cst.setString(1,des);
			cst.setDouble(2,sal);
			cst.registerOutParameter(3,Types.VARCHAR);
			cst.executeQuery();
			System.out.println("Insurance Scheme is "+cst.getString(3));
			String updateQry="UPDATE emp_jdbc set emp_ins=? WHERE emp_des=? and emp_sal=?";
			PreparedStatement pst=con.prepareStatement(updateQry);
			pst.setString(1,cst.getString(3));
			pst.setString(2,des);
			pst.setDouble(3,sal);
			pst.executeUpdate();
			System.out.println("Insurance Scheme is updated... ");
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
