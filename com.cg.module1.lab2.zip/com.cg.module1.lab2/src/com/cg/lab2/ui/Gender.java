package com.cg.lab2.ui;

public enum Gender {

	M,F;
}
