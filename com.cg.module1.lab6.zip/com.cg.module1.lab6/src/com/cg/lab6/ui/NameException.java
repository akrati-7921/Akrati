package com.cg.lab6.ui;

class NameOccurException extends Exception {
	
	private String name;
	NameOccurException(String name)
	{
		this.name=name;
	}
	
	public String toString()
	{
		return name+" is not provided"; 
	} 
}

class PersonName{
	String firstName;
	String lastName;
	
	void getDetails(String firstName,String lastName) throws NameOccurException 
	{
		this.firstName=firstName;
		this.lastName=lastName;
		if (firstName.isEmpty() && lastName.isEmpty())
			throw new NameOccurException("Full name");
		else if(lastName.isEmpty())
			throw new NameOccurException("Last name");
		else if(firstName.isEmpty())
			throw new NameOccurException("First name");
	}
	
	void showDetails()
	{
		System.out.println("Full name is: "+ firstName+" "+ lastName);
	}
	
}
public class NameException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PersonName per=new PersonName();
		try {
			per.getDetails("Akrati","Agrawal");
			//per.getDetails("","Agrawal");
			//per.getDetails("Akrati","");
			per.getDetails("","");
		}
		catch (NameOccurException e) {
			// TODO: handle exception
			System.out.println(e); 
		}
		finally
		{
			per.showDetails();
		}
		
	}

}
