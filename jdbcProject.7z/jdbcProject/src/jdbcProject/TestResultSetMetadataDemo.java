package jdbcProject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.ems.util.DBUtil;

public class TestResultSetMetadataDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Connection con=DBUtil.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT * from emp1");
			ResultSetMetaData rsmd=rs.getMetaData();
			int colCount=rsmd.getColumnCount();
			System.out.println("No.of Columns: "+ colCount);
			for(int i=1;i<=colCount;i++)
			{
				System.out.println(i+":  Column Name: "+rsmd.getColumnName(i)+"\tColumn type: "+rsmd.getColumnTypeName(i));
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
