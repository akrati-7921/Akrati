package com.cg.lab4.ui;

import java.util.Random;

import com.cg.lab4.bean.Account;
import com.cg.lab4.bean.Person;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random random=new Random();
		Person smith=new Person("Smith",22);
		Person kathy=new Person("Kathy",24);
		Account accSmith=new Account(random.nextLong(),2000,smith);
		Account accKathy=new Account(random.nextLong(),3000,kathy);
		accSmith.deposit(2000);
		accKathy.withdraw(2000);
		
		System.out.println("Current Balance of smith is:"+accSmith.getBalance());
		System.out.println("Current Balance of Kathy is:"+accKathy.getBalance());
		System.out.println(accSmith);
		System.out.println(accKathy);
		
	}

}
