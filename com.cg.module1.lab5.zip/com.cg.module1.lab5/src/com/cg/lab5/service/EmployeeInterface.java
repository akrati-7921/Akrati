package com.cg.lab5.service;

import com.cg.lab5.exception.EmployeeException;

public interface EmployeeInterface {

	public void getDetails() throws EmployeeException;
	public String insuranceScheme();
	public void setDetails();
}
