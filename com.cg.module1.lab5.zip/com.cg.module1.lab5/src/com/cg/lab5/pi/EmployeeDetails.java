package com.cg.lab5.pi;

import com.cg.lab5.exception.EmployeeException;
import com.cg.lab5.service.Service;

public class EmployeeDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Service s=new Service();
		try {
			s.getDetails();
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		s.setDetails();
		System.out.println(s.insuranceScheme());
	}

}
