package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.bean.Author;
import com.cg.ems.bean.Book;

public interface IAuthorDAO {

	public ArrayList<Book> getDetails();
	public ArrayList<Book> getDetailsByAuthor(String authorName);
	public ArrayList<Book> getDetailsByPrice(float lowRange,float highRange);
	public ArrayList<Author> getDetailsByBookId(int bookId);
}
