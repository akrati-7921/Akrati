package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.cg.ems.bean.Author;
import com.cg.ems.bean.Book;
import com.cg.ems.util.JPAUtil;

public class AuthorDAOImpl implements IAuthorDAO{

	EntityManager em=null;
	EntityTransaction entityTran=null;
	
	public AuthorDAOImpl()
	{
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}
	
	
	@Override
	public ArrayList<Book> getDetails() {
		// TODO Auto-generated method stub
		TypedQuery<Book> tq=em.createQuery("SELECT book from Book book",Book.class);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}
	
	@Override
	public ArrayList<Book> getDetailsByAuthor(String authorName) {
		// TODO Auto-generated method stub
		
		String selAllQry="SELECT books from Book books, IN(books.authorSet) a where a.Name='"+authorName+"'";
		TypedQuery<Book> tq=em.createQuery(selAllQry,Book.class);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}
	
	@Override
	public ArrayList<Book> getDetailsByPrice(float lowRange,float highRange) {
		// TODO Auto-generated method stub
		
		String selAllQry="SELECT books from Book books where books.price between :lowRange and :highRange";
		TypedQuery<Book> tq=em.createQuery(selAllQry,Book.class);
		tq.setParameter("lowRange",lowRange);
		tq.setParameter("highRange",highRange);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}
	
	@Override
	public ArrayList<Author> getDetailsByBookId(int bookId) {
		// TODO Auto-generated method stub
		
		String selAllQry="SELECT author from Author author , IN(author.bookSet) b where b.bookId='"+bookId+"'";
		TypedQuery<Author> tq=em.createQuery(selAllQry,Author.class);
		ArrayList<Author> authList=(ArrayList)tq.getResultList();
		return authList;
	}
	
	

}
