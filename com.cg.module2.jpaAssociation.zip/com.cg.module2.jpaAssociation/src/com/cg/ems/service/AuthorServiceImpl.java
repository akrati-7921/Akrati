package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.Author;
import com.cg.ems.bean.Book;
import com.cg.ems.dao.AuthorDAOImpl;

public class AuthorServiceImpl implements IAuthorService{

	AuthorDAOImpl authDao =null;
	
	public AuthorServiceImpl() {
		// TODO Auto-generated constructor stub
		authDao=new AuthorDAOImpl();
	}

	@Override
	public ArrayList<Book> getDetails() {
		// TODO Auto-generated method stub
		return authDao.getDetails();
	}

	@Override
	public ArrayList<Book> getDetailsByAuthor(String authorName) {
		// TODO Auto-generated method stub
		return authDao.getDetailsByAuthor(authorName);
	}

	@Override
	public ArrayList<Book> getDetailsByPrice(float lowRange,float highRange) {
		// TODO Auto-generated method stub
		return authDao.getDetailsByPrice(lowRange,highRange);
	}

	@Override
	public ArrayList<Author> getDetailsByBookId(int bookId) {
		// TODO Auto-generated method stub
		return authDao.getDetailsByBookId(bookId);
	}
	
	
}
