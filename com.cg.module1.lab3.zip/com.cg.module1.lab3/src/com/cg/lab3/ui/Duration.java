package com.cg.lab3.ui;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Duration {

	public static void duration(LocalDate userGiven)
	{
		LocalDate currentDate=LocalDate.now();
		Period period=userGiven.until(currentDate);
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter any random date");
		int date=scan.nextInt();
		int month=scan.nextInt();
		int year=scan.nextInt();
		LocalDate userGiven=LocalDate.of(year, month, date);
		scan.close();
		Duration.duration(userGiven);

	}

}
