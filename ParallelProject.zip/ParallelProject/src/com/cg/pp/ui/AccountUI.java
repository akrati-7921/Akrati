package com.cg.pp.ui;

import java.util.Scanner;
import com.cg.pp.service.AccountSevice;
import com.cg.pp.service.IAccountService;

public class AccountUI {
	
	public static void main(String ag[])
	{
		IAccountService service=new AccountSevice();
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("1. Create Account\n2. Withdraw Amount\n3.Deposit "
					+ "Amount\n4. Show Balance\n5. Print Transaction\n6. Fund Transfer"
					+ "\n7. Exit\nEnter your choice");
			int choice= scan.nextInt();
			switch(choice)
			{
				case 1:{
					System.out.println("Enter account number");
					int accNo=scan.nextInt();
					System.out.println("Enter account holder name");
					scan.nextLine();
					String name=scan.nextLine();
					System.out.println("Enter mobile number");
					String mobileNo=scan.nextLine();
					System.out.println("Enter starting amount");
					double amount=scan.nextDouble();
					service.createAccount(accNo, name, mobileNo, amount);
					break;
				}
				case 2:{
					System.out.println("Enetr the id whose amount you want to withdraw");
					int withdrawAccNo=scan.nextInt();
					System.out.println("Enter the amount you want to withdraw");
					double withdrawAmount=scan.nextDouble();
					service.withdraw(withdrawAccNo,withdrawAmount);
					System.out.println(service.showBalance(withdrawAccNo));
					break;
				}
				case 3:{
					System.out.println("Enetr the id whose amount you want to deposit");
					int depositAccNo=scan.nextInt();
					System.out.println("Enter the amount you want to deposit");
					double depositAmount=scan.nextDouble();
					service.deposit(depositAccNo,depositAmount);
					System.out.println(service.showBalance(depositAccNo));
					break;
				}
				case 4:{
					System.out.println("Enetr the id whose balance you want to check");
					int accId=scan.nextInt();
					System.out.println("Total balance is: "+service.showBalance(accId));
					break;
				}
				case 5:{
					System.out.println("Enetr the id whose transaction you want");
					int printAccId=scan.nextInt();
					System.out.println(service.printTtansaction(printAccId));
					break;
				}
				case 6:{
					System.out.println("Enetr the id of sender");
					int senderAccId=scan.nextInt();
					System.out.println("Enetr the id of receiver");
					int receiverAccId=scan.nextInt();
					System.out.println("Enter the amount you want to transfer");
					double sendAmount=scan.nextDouble();
					service.fundTransfer(senderAccId, receiverAccId, sendAmount);
					System.out.println("Sender's Updated Balance Details"+service.showBalance(senderAccId));
					System.out.println("Receiver's Updated Balance Details"+service.showBalance(receiverAccId));   
					break;
				}
				case 7:{
					System.exit(0);
					break;
				}
			}
		}
	}
}