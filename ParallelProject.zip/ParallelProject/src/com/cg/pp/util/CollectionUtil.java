package com.cg.pp.util;

import java.util.HashMap;
import java.util.Map;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Wallet;

public class CollectionUtil {

	private static Map<String,AccountHolder> account=new HashMap<String, AccountHolder>();
	
	static
	{
		account.put("7088559555",new AccountHolder("Akrati","Agrawal","Female",22,new Wallet(25000)));
	}
	
	public Map<String, AccountHolder> getAccountDetails()
	{
		return account;
	}
}
