package com.cg.pp.dao;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.bean.Wallet;
import com.cg.pp.util.CollectionUtil;

public class AccountDao implements IAccountDao{

	CollectionUtil collect=null;
	Map<String,AccountHolder> accountMap=null;
	AccountHolder account=null;
	Wallet wallet=null;
	double balance=0.0;
	int transactionID=1;
	
	public AccountDao() {
		// TODO Auto-generated constructor stub
		collect=new CollectionUtil();
		accountMap=collect.getAccountDetails();
	}

	@Override
	public AccountHolder createAccount(String firstName, String lastName, String mobileNo, String gender, int age,
			double amount) {
		// TODO Auto-generated method stub
		
		return accountMap.put(mobileNo, new AccountHolder(firstName,lastName,gender,age,new Wallet(amount)));
	}

	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		
		account=accountMap.get(mobileNo);
		double withdrawBalance=account.getWallet().getBalance();
		withdrawBalance=withdrawBalance-amount;
		wallet.setBalance(withdrawBalance);
		account.setWallet(wallet);
		
		//Update transaction
		Transactions transaction= new Transactions();
		transaction.setAmount(account.getWallet().getBalance());
		transaction.setMobileNumber(account.getMobileno());
		transaction.setTransactionId(transactionID++);
		transaction.setTransactionType("Withdraw");
		account.getListTransaction().add(transaction);
		return account;
	}

	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		
		account=accountMap.get(mobileNo);
		double depositBalance=account.getWallet().getBalance();
		depositBalance=depositBalance+amount;
		wallet.setBalance(depositBalance);
		account.setWallet(wallet);
		//Update transaction
		Transactions transaction= new Transactions();
		transaction.setAmount(account.getWallet().getBalance());
		transaction.setMobileNumber(account.getMobileno());
		transaction.setTransactionId(transactionID++);
		transaction.setTransactionType("Deposit");
		account.getListTransaction().add(transaction);
		return account;
	}

	@Override
	public double showBalance(String mobileNo) {
		// TODO Auto-generated method stub
		
		account=accountMap.get(mobileNo);
		return account.getWallet().getBalance();
	}

	@Override
	public List<AccountHolder> fundTransfer(String senderMobileNo,String receiverMobileNo, double amount) {
		// TODO Auto-generated method stub
		List<AccountHolder> accountHolder=new LinkedList<AccountHolder>();
		AccountHolder senderAccount=accountMap.get(senderMobileNo);
		AccountHolder receiverAccount=accountMap.get(receiverMobileNo);
		double receiverAmount=receiverAccount.getWallet().getBalance();
		receiverAmount=receiverAmount-amount;
		double senderAmount=senderAccount.getWallet().getBalance();
		senderAmount=senderAmount+amount;
		Wallet senderWallet=new Wallet();
		Wallet receiverWallet=new Wallet();
		senderWallet.setBalance(senderAmount);
		receiverWallet.setBalance(receiverAmount);
		senderAccount.setWallet(senderWallet);
		receiverAccount.setWallet(receiverWallet);
		accountHolder.add(receiverAccount);
		accountHolder.add(senderAccount);
		
		//Update transaction
		//Sender's account
		senderAccount.getTranscation().setAmount(senderAccount.getWallet().getBalance());
		senderAccount.getTranscation().setMobileNumber(senderAccount.getMobileno());
		senderAccount.getTranscation().setTransactionId(transactionID++);
		senderAccount.getTranscation().setTransactionType("Fund transfered");
		senderAccount.getListTransaction().add(senderAccount.getTranscation());
				
		//Reciever's account
		receiverAccount.getTranscation().setAmount(receiverAccount.getWallet().getBalance());
		receiverAccount.getTranscation().setMobileNumber(receiverAccount.getMobileno());
		receiverAccount.getTranscation().setTransactionId(transactionID++);
		receiverAccount.getTranscation().setTransactionType("Fund Recieved");
		receiverAccount.getListTransaction().add(receiverAccount.getTranscation());
				
		return accountHolder;
	}

	@Override
	public List<Transactions> printTtansaction(String mobileNo) {
		// TODO Auto-generated method stub
		
		Iterator<Entry<String, AccountHolder>> dataTrav=accountMap.entrySet().iterator();
		while(dataTrav.hasNext())
		{
			Map.Entry<String, AccountHolder> data=(Map.Entry<String, AccountHolder>)dataTrav.next();
				if(data.getValue().getMobileno().equals(mobileNo))
				{
					account=data.getValue();
					return data.getValue();
				}	
		}			
	}

}
