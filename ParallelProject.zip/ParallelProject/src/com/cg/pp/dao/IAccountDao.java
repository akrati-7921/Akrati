package com.cg.pp.dao;

import java.util.List;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;

public interface IAccountDao {

	public AccountHolder createAccount(String firstName,String lastName,String mobileNo,String gender,int age,double amount);
	public AccountHolder withdrawAmount(String mobileNo,double amount);
	public AccountHolder depositAmount(String mobileNo,double amount);
	public double showBalance(String mobileNo);
	public List<Transactions> printTtansaction(String mobileNo);
	public List<AccountHolder> fundTransfer(String senderMobileNo,String receiverMobileNo,double amount);
	
}
