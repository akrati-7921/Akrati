package com.cg.pp.bean;

public class Wallet {

	private double balance;
	
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wallet(double balance) {
		super();
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}
	
}
