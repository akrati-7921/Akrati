package com.cg.pp.bean;

import java.util.LinkedList;

public class AccountHolder {

	private String firstName;
	private String lastName;
	private String mobileno;
	private String gender;
	private int age;
	private Wallet wallet;
	Transactions transcation=new Transactions();
	private LinkedList<Transactions> listTransaction=new LinkedList<>();
	
	public AccountHolder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountHolder(String firstName, String lastName, String gender, int age, Wallet wallet) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.wallet = wallet;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Transactions getTranscation() {
		return transcation;
	}

	public void setTranscation(Transactions transcation) {
		this.transcation = transcation;
	}

	public LinkedList<Transactions> getListTransaction() {
		return listTransaction;
	}

	public void setListTransaction(LinkedList<Transactions> listTransaction) {
		this.listTransaction = listTransaction;
	}

	@Override
	public String toString() {
		return "AccountHolder [firstName=" + firstName + ", lastName=" + lastName + ", mobileno=" + mobileno
				+ ", gender=" + gender + ", age=" + age + ", wallet=" + wallet + "]";
	}
	
}
