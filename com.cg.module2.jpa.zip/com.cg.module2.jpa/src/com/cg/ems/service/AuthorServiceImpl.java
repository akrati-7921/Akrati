package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.bean.Author;
import com.cg.ems.dao.AuthorDAOImpl;

public class AuthorServiceImpl implements IAuthorService{

	AuthorDAOImpl authDao = new AuthorDAOImpl();
	
	@Override
	public Author addAuth(Author auth) {
		// TODO Auto-generated method stub
		return authDao.addAuth(auth);
	}

	@Override
	public ArrayList<Author> fetchAllAuth() {
		// TODO Auto-generated method stub
		return authDao.fetchAllAuth();
	}

	@Override
	public Author deleteAuth(int authId) {
		// TODO Auto-generated method stub
		return authDao.deleteAuth(authId);
	}

	@Override
	public Author getAuthbyAuthid(int authId) {
		// TODO Auto-generated method stub
		return authDao.getAuthbyAuthid(authId);
	}

	@Override
	public Author updateAuth(int authId, String newFName, String newMName, String newLName, String newPNo) {
		// TODO Auto-generated method stub
		return authDao.updateAuth(authId, newFName, newMName, newLName, newPNo);
	}

}
