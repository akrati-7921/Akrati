package com.cg.module1.lab9.ui;

import java.io.FileInputStream;
import java.io.IOException;

public class Even {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream in = new FileInputStream("C:\\practice\\com.cg.module1.lab9\\src\\com\\cg\\module1\\lab9\\ui\\number.txt");
		
		int i;
		String s="";
		while((i = in.read()) != -1) {
			s += (char)i;
		}
		
		String num[] = s.split(",");
		
		int []numbers = new int[num.length];
		
		for(int x=0; x< num.length; x++) {
			
			numbers[x] = Integer.parseInt(num[x].trim());
			
			if(numbers[x] % 2 == 0) {
				System.out.println(numbers[x]);
			}
		}
		
		in.close();

	}

}
