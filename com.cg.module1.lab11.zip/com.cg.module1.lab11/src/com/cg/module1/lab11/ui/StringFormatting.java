package com.cg.module1.lab11.ui;

import java.util.function.Consumer;

public class StringFormatting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<String> consumer= (str)->System.out.println(str.replace(""," ").trim());
		consumer.accept("hello");
		
	}

}
