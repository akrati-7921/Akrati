package com.cg.module1.lab11.ui;

import java.util.Scanner;

interface Number
{
	public void factorial(int n);
}
public class Factorial implements Number{

	public void factorial(int n)
	{
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println("Factorial of "+ n+ " is: " + fact );
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter number");
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		Number num=new Factorial()::factorial;
		num.factorial(n);
		scan.close();
		
	}

}
