package com.cg.module1.lab11.ui;

import java.util.Scanner;
import java.util.function.BiFunction;


public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan=new Scanner(System.in);
		System.out.println("Enter first number");
		double x=scan.nextInt();
		System.out.println("Enter second number");
		double y=scan.nextInt();
		
		BiFunction<Double, Double, Double> bi = (i,j)->Math.pow(i,j);
		System.out.println(bi.apply(x,y));
		scan.close();
		
	}

}
