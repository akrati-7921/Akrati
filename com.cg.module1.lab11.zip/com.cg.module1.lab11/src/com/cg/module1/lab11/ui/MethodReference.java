package com.cg.module1.lab11.ui;

interface Student
{
	public void display();
}
public class MethodReference implements Student {

	String name;
	int age;
	
	public MethodReference(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Student stu=new MethodReference("Akrati",22)::display;
		stu.display();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
		System.out.println("Name is:" +name+ "\nAge is:" +age);
	}

}
